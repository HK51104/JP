import { Link } from "react-router-dom";
import { useEffect, useState } from "react";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // MOCK SAFE DATA (frontend only mode)
    setTimeout(() => {
      setProducts([
        { id: 1, product_name: "Polymer A", product_grade: "A1", category: "Plastic", current_price: 120 },
        { id: 2, product_name: "Polymer B", product_grade: "B2", category: "Resin", current_price: 95 },
        { id: 3, product_name: "Polymer C", product_grade: "C3", category: "Industrial", current_price: 150 },
      ]);
      setLoading(false);
    }, 500);
  }, []);

  const filtered = (products || []).filter((p) =>
    `${p.product_name} ${p.product_grade} ${p.category}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="p-6 text-gray-400 animate-pulse">
        Loading market feed...
      </div>
    );
  }

  return (
    <div className="container p-6 space-y-4">

      {/* HEADER */}
      <div>
        <h1 className="text-2xl font-bold">Products</h1>
        <p className="text-sm text-gray-400">
          Live polymer market universe
        </p>
      </div>

      {/* SEARCH */}
      <input
        className="w-full p-2 rounded"
        placeholder="Search products..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* TABLE */}
      <div className="card overflow-hidden">

        <table className="w-full text-sm">

          <thead>
            <tr>
              <th className="p-3 text-left">Product</th>
              <th className="p-3 text-left">Grade</th>
              <th className="p-3 text-left">Category</th>
              <th className="p-3 text-right">Price</th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((p) => (
              <tr key={p.id}>
                <td className="p-3">
                  <Link className="text-blue-400" to={`/products/${p.id}`}>
                    {p.product_name}
                  </Link>
                </td>
                <td className="p-3">{p.product_grade}</td>
                <td className="p-3">{p.category}</td>
                <td className="p-3 text-right font-semibold">
                  ₹{p.current_price}
                </td>
              </tr>
            ))}
          </tbody>

        </table>

      </div>
    </div>
  );
}