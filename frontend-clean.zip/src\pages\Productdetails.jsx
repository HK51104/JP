import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getProduct, getProductHistory } from "../api";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

export default function ProductDetails() {
  const { id } = useParams();

  const [product, setProduct] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const productRes = await getProduct(id);
        const historyRes = await getProductHistory(id);

        setProduct(productRes.data);

        // FIX: backend returns "time" not "recorded_at"
        const formattedHistory = historyRes.data.map((item) => ({
          date: new Date(item.time).toLocaleDateString(),
          price: item.price,
        }));

        setHistory(formattedHistory);
      } catch (err) {
        console.error("ProductDetails error:", err);
        setProduct(null);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [id]);

  if (loading) {
    return <div className="p-6">Loading...</div>;
  }

  if (!product) {
    return <div className="p-6">Product not found.</div>;
  }

  return (
    <div className="p-6 space-y-6">

      <Link
        to="/products"
        className="inline-block text-blue-600 hover:underline"
      >
        ← Back to Products
      </Link>

      {/* PRODUCT INFO */}
      <div className="border rounded-lg p-6 shadow-sm">
        <h1 className="text-3xl font-bold">
          {product.product_name}
        </h1>

        <p className="text-gray-500 mt-2">
          {product.product_grade}
        </p>

        <div className="mt-4">
          {/* FIX: current_price instead of price */}
          <span className="text-4xl font-bold">
            ₹{product.current_price}
          </span>

          <div className="text-sm text-gray-500 mt-1">
            Category: {product.category}
          </div>

          <div className="text-sm text-gray-500">
            Updated:{" "}
            {new Date(product.last_updated).toLocaleString()}
          </div>
        </div>
      </div>

      {/* CHART */}
      <div className="border rounded-lg p-6 shadow-sm">
        <h2 className="text-xl font-semibold mb-4">
          Price History
        </h2>

        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={history}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />

            <Line
              type="monotone"
              dataKey="price"
              stroke="#2563eb"
              strokeWidth={3}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}