import { Link, NavLink } from "react-router-dom";
import { LayoutDashboard, Boxes, Star, BellRing, Activity } from "lucide-react";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/products", label: "Products", icon: Boxes },
  { to: "/watchlist", label: "Watchlist", icon: Star },
  { to: "/alerts", label: "Alerts", icon: BellRing },
];

export default function AppShell({ children }) {
  return (
    <div className="min-h-screen flex flex-col">

      {/* TOP BAR */}
      <div className="h-9 border-b border-white/10 flex items-center px-4 text-[11px] font-mono">
        <div className="flex items-center gap-2 text-yellow-400 font-bold">
          <Activity className="size-3 animate-pulse" />
          POLYMETRIC LIVE
        </div>

        <div className="ml-6 text-muted">
          LIVE MARKET DASHBOARD
        </div>
      </div>

      {/* HEADER */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur">
        <div className="max-w-[1400px] mx-auto px-6 h-14 flex items-center">

          <Link to="/" className="font-bold text-lg">
            POLY<span className="text-yellow-400">METRIC</span>
          </Link>

          <nav className="ml-8 flex gap-2">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-1.5 rounded-md text-sm transition ${
                    isActive
                      ? "bg-white/10 border border-white/10"
                      : "text-muted hover:text-white"
                  }`
                }
              >
                <n.icon className="size-4" />
                {n.label}
              </NavLink>
            ))}
          </nav>

        </div>
      </header>

      {/* MAIN */}
      <main className="flex-1 max-w-[1400px] mx-auto w-full px-6 py-8">
        {children}
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/10 px-6 py-3 text-xs text-muted flex justify-between">
        <span>POLYMETRIC © 2026</span>
        <span>LIVE DATA FEED</span>
      </footer>

    </div>
  );
}