import { useEffect, useState } from "react";
import axios from "axios";
import { Boxes, Layers, Clock, Activity } from "lucide-react";
import { Link } from "react-router-dom";

function StatCard({ label, value, icon: Icon }) {
  return (
    <div className="card p-4">
      <div className="flex justify-between text-muted text-xs mb-2">
        {label}
        <Icon className="size-4" />
      </div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [movers, setMovers] = useState([]);

  useEffect(() => {
    const load = async () => {
      try {
        const d = await axios.get("http://localhost:8000/dashboard");
        const m = await axios.get("http://localhost:8000/top-movers");

        setData(d.data);
        setMovers(Array.isArray(m.data) ? m.data : []);
      } catch (e) {
        console.error(e);
      }
    };

    load();
  }, []);

  if (!data) {
    return <div className="text-muted">Loading dashboard...</div>;
  }

  return (
    <div className="space-y-6">

      <h1 className="text-3xl font-bold">Market Overview</h1>

      <div className="grid grid-cols-4 gap-4">
        <StatCard label="Products" value={data.total_products} icon={Boxes} />
        <StatCard label="Categories" value={data.total_categories} icon={Layers} />
        <StatCard label="Updated" value={data.updated_today} icon={Clock} />
        <StatCard label="Market" value="+0.42%" icon={Activity} />
      </div>

      <div className="card p-4">
        <h2 className="font-semibold mb-3">Top Movers</h2>

        {movers.map((p) => (
          <Link
            key={p.id}
            to={`/products/${p.id}`}
            className="flex justify-between py-2 border-b border-white/5 hover:bg-white/5"
          >
            <span>{p.name}</span>
            <span>₹{p.price}</span>
          </Link>
        ))}
      </div>

    </div>
  );
}