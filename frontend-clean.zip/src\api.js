import axios from "axios";

const API = "http://127.0.0.1:8000";

// PRODUCTS
export const getProducts = async () => {
  const res = await axios.get(`${API}/products`);
  return res.data;
};

// STATS
export const getStats = async () => {
  const res = await axios.get(`${API}/stats`);
  return res.data;
};

// TOP MOVERS
export const getTopMovers = async () => {
  const res = await axios.get(`${API}/top-movers`);
  return res.data;
};

// SINGLE PRODUCT
export const getProduct = async (id) => {
  const res = await axios.get(`${API}/products/${id}`);
  return res.data;
};

// HISTORY
export const getProductHistory = async (id) => {
  const res = await axios.get(`${API}/products/${id}/history`);
  return res.data;
};

// DASHBOARD
export const getDashboard = async () => {
  const res = await axios.get(`${API}/dashboard`);
  return res.data;
};