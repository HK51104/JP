import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useAlerts } from "@/lib/watchlist";
import { Bell, Mail, MessageSquare, Smartphone, Trash2 } from "lucide-react";
import { toast } from "sonner";

const CHANNELS = [
  { k: "email", icon: Mail, label: "Email" },
  { k: "sms", icon: Smartphone, label: "SMS" },
  { k: "whatsapp", icon: MessageSquare, label: "WhatsApp" },
];

export default function Alerts() {
  const [params] = useSearchParams();
  const { alerts, add, remove } = useAlerts();

  const [direction, setDirection] = useState("below");
  const [threshold, setThreshold] = useState("");
  const [channels, setChannels] = useState(["email"]);

  const toggleChan = (c) =>
    setChannels((prev) =>
      prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]
    );

  const submit = (e) => {
    e.preventDefault();
    const t = parseFloat(threshold);

    if (!t || t <= 0) return toast.error("Enter valid price");
    if (channels.length === 0) return toast.error("Select channel");

    add({
      productId: params.get("productId") || "1",
      threshold: t,
      direction,
      channels,
    });

    setThreshold("");
    toast.success("Alert created");
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Alerts</h1>

      {/* FORM */}
      <form onSubmit={submit} className="space-y-4 p-4 border rounded">
        <div className="flex gap-2">
          <button type="button" onClick={() => setDirection("below")}>
            Below
          </button>
          <button type="button" onClick={() => setDirection("above")}>
            Above
          </button>
        </div>

        <input
          type="number"
          value={threshold}
          onChange={(e) => setThreshold(e.target.value)}
          placeholder="Enter price"
          className="border p-2 w-full"
        />

        <div className="flex gap-2">
          {CHANNELS.map((c) => (
            <button
              key={c.k}
              type="button"
              onClick={() => toggleChan(c.k)}
              className={channels.includes(c.k) ? "text-green-500" : ""}
            >
              <c.icon size={14} /> {c.label}
            </button>
          ))}
        </div>

        <button type="submit" className="bg-blue-500 text-white px-3 py-2">
          Create Alert
        </button>
      </form>

      {/* LIST */}
      <div className="mt-6">
        {alerts.map((a) => (
          <div key={a.id} className="flex justify-between border p-2">
            <div>
              {a.direction} ₹{a.threshold} ({a.channels.join(", ")})
            </div>
            <button onClick={() => remove(a.id)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}