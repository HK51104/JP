export default function Watchlist() {
  const items = [
    { id: 1, name: "Polymer A", price: 120, change: +2.3 },
    { id: 2, name: "Polymer B", price: 95, change: -1.2 },
  ];

  return (
    <div className="container p-6 space-y-4">

      <h1 className="text-2xl font-bold">Watchlist</h1>

      <div className="grid md:grid-cols-2 gap-4">

        {items.map((p) => (
          <div key={p.id} className="card p-4">

            <div className="flex justify-between">
              <div>
                <div className="text-sm text-gray-400">Polymer</div>
                <div className="font-semibold">{p.name}</div>
              </div>

              <div className={p.change > 0 ? "text-green-500" : "text-red-500"}>
                {p.change > 0 ? "+" : ""}{p.change}%
              </div>
            </div>

            <div className="text-xl font-bold mt-3">
              ₹{p.price}
            </div>

          </div>
        ))}

      </div>
    </div>
  );
}